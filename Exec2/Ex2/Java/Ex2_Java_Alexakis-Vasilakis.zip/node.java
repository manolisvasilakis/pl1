class node {
	private int i,j;
	private String s;
	
	public node (int i, int j, String s) {
		this.i = i;
		this.j = j;
		this.s = s;
	}
	
	public int geti() {
		return i;
	}
	
	public int getj() {
		return j;
	}
	
	public String getstring() {
		return s;
	}
}
